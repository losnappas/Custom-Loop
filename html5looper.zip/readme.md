## CUSTOM LOOP

loop parts of audio/video.

right click -> looper -> set start/end -> it sets the time to whatever second you're currently at.

enjoy

right click to enable on a new media element.

only works on 1 media element at a time.